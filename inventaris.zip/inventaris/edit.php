<?php include "header.php"; ?>

<?php
// Fungsi untuk mengupload gambar
function upload()
{
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    // cek apakah tidak ada gambar yang diupload
    if ($error === 4) {
        return false;
    }

    // cek apakah yang diupload adalah gambar
    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));
    if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
        echo "<script>alert('Yang diupload bukan file gambar!');</script>";
        return false;
    }

    // cek jika ukuran terlalu besar
    if ($ukuranFile > 1000000) {
        echo "<script>alert('Ukuran gambar terlalu besar!');</script>";
        return false;
    }

    // lolos pengecekan, gambar siap diupload
    // generate nama file baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensiGambar;

    // Pindahkan file
    move_uploaded_file($tmpName, 'img/' . $namaFileBaru);

    return $namaFileBaru;
}

?>

<!-- Outer Row -->
<div class="row justify-content-center">
    <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-6 d-lg-block bg-info shadow-lg p-5 text-center">
                        <!-- panggil file image -->
                        <?php include "image.php"; ?>
                        <br>
                        <br>
                        <br>
                        <h3 class="text-white">Sistem Informasi Buku Tamu</h3>
                        <!-- panggil file text -->
                        <?php include "text.php"; ?><br>
                        <h4><small class="text-white">Sukoharjo, Jawa Tengah</small></h4>
                    </div>
                    <?php
                    // Memeriksa apakah parameter "id" ada dalam URL
                    if (isset($_GET['id'])) {
                        // Mendapatkan ID dari parameter URL
                        $id = $_GET['id'];

                        // Mendapatkan data berdasarkan ID
                        $sql = "SELECT * FROM tdata WHERE id = '$id'";
                        $result = mysqli_query($koneksi, $sql);

                        if (!$result) {
                            echo "Terjadi kesalahan: " . mysqli_error($koneksi);
                        } elseif (mysqli_num_rows($result) > 0) {
                            $row = mysqli_fetch_assoc($result);
                            // Menampilkan data dalam form untuk diedit
                    
                            // Memeriksa apakah form telah disubmit untuk menyimpan perubahan
                            if (isset($_POST['submit'])) {
                                // Mendapatkan data yang diinput dari form
                                $nama = htmlspecialchars($_POST['nama']);
                                $alamat = htmlspecialchars($_POST['alamat']);
                                $tujuan = htmlspecialchars($_POST['tujuan']);
                                $nope = htmlspecialchars($_POST['nope']);
                                $gambarLama = htmlspecialchars($_POST['gambarLama']);
                                
                                // Cek apakah ada gambar baru yang diupload
                                if ($_FILES['gambar']['error'] === 4) {
                                    $gambar = $gambarLama;
                                } else {
                                    $gambar = upload();
                                    if (!$gambar) {
                                        $gambar = $gambarLama;
                                    }
                                }

                                // Update data di database
                                $updateSql = "UPDATE tdata SET nama = '$nama', alamat = '$alamat', tujuan = '$tujuan', nope = '$nope', gambar = '$gambar' WHERE id = '$id'";
                                $updateResult = mysqli_query($koneksi, $updateSql);

                                if ($updateResult) {
                                    // Jika berhasil disimpan, tampilkan pesan sukses dengan menggunakan fungsi echo "<script></script>"
                                    echo "<script>alert('Data Berhasil Diubah!'); window.location.href = 'admin.php';</script>";
                                } else {
                                    echo "Terjadi kesalahan: " . mysqli_error($koneksi);
                                }
                            }
                            ?>

                            <div class="col-lg-6">
                                <div class="shadow bg-gradient-light p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4"><b>Edit Data Pengunjung</b></h1>
                                    </div>
                                    <form class="user" action="#" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <input type="text" name="nama" class="form-control form-control-user"
                                                placeholder="Nama" value="<?= $row['nama']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="alamat" class="form-control form-control-user"
                                                placeholder="Alamat" value="<?= $row['alamat']; ?>" minlength="3" required>
                                        </div>
                                        <div class="form-group">
                                            <select name="tujuan" class="form-control " minlength="3" required>
                                                <option value="">Satuan Barang</option>
                                                <option value="pcs" <?= ($row['tujuan'] == 'pcs') ? 'selected' : ''; ?>>pcs</option>
                                                <option value="pack" <?= ($row['tujuan'] == 'pack') ? 'selected' : ''; ?>>pack</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="nope" class="form-control form-control-user"
                                                placeholder="Jumlah Barang" value="<?= $row['nope']; ?>" required
                                                pattern="\d+" title="Input hanya boleh mengandung angka">
                                        </div>
                                        <div class="form-group">
                                            <img src="img/<?= $row['gambar']; ?>" alt="<?= $row['nama'] ?>" style="width: 100px; height: auto;">
                                            <input type="file" name="gambar">
                                            <input type="hidden" name="gambarLama" value="<?= $row['gambar']; ?>">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-primary btn-user btn-block">Simpan
                                            Data</button>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="#">Inspiration on YouTube <?= date('Y') ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } else {
                            echo "Data tidak ditemukan.";
                        }
                    } else {
                        echo "ID tidak ditemukan.";
                    }

                    // Menutup koneksi ke database
                    mysqli_close($koneksi);
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
