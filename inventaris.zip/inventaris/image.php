<!-- style -->
  <style>
    #gambar {
      width: 200px;
      transition: 0.3s;
    }
    #gambar:hover {
      transform: scale(1.2);
    }
  </style>

<!-- gambar awal -->
  <img id="gambar" src="assets/img/airmu4.png" />

  <!-- script -->
  <script>
    var gambarAwal = "assets/img/airmu4.png";
    var gambarAkhir = "assets/img/logo s.png";
  
    var gambar = document.getElementById('gambar');
    gambar.addEventListener("mouseover", function() {
      gambar.src = gambarAkhir;
    });
  
    gambar.addEventListener("mouseout", function() {
      gambar.src = gambarAwal;
    });
  </script>
