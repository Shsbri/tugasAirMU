<?php
    $server = "localhost";
    $user = "root";
    $password = "";  
    $database = "dbinventaris";

    // Membuat koneksi
    $koneksi = mysqli_connect($server, $user, $password, $database) or die(mysqli_error($koneksi));

    // Memeriksa koneksi
    if (!$koneksi) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }
?>