   <!-- panggil file header -->


   <?php
    include "header.php";


    // Uji Jika tombol simpan diklik
    if (isset($_POST['bsimpan'])) {
        $tgl = date('Y-m-d');

        //tmlspecialchars agar inputan lebih aman dari injection
        $nama = htmlspecialchars($_POST['nama'], ENT_QUOTES);
        $alamat = htmlspecialchars($_POST['alamat'], ENT_QUOTES);
        $tujuan = htmlspecialchars($_POST['tujuan'], ENT_QUOTES);
        $nope = htmlspecialchars($_POST['nope'], ENT_QUOTES);

        // upload gambar
        $gambar = upload();
        if (!$gambar) {
            return false;
        }

        //persiapan query simpan data
        $simpan = mysqli_query($koneksi, "INSERT INTO tdata VALUES ('','$tgl', '$nama', 
    '$alamat', '$tujuan', '$nope', '$gambar')");

        // Uji jika simpan data sukses
        if ($simpan) {
            echo "<script>alert('Simpan data sukses, Terima Kasih..!');
              document.location='?'</script>";
        } else {
            echo "<script>alert('Simpan Data GAGAL!!!');
        document.location='?'</script>";
        }
    }

    function upload()
    {

        $namaFile = $_FILES['gambar']['name'];
        $ukuranFile = $_FILES['gambar']['size'];
        $error = $_FILES['gambar']['error'];
        $tmpName = $_FILES['gambar']['tmp_name'];
        var_dump($tmpName);

        // cek apakah tidak ada gambar yang di upload
        if ($error === 4) {
            echo "<script>
        alert('pilih gambar terlebih dahulu!')
        document.location='?'
        </script>";
            return false;
        }

        // cek apakah yang diupload adalah gambar
        $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
        $ekstensiGambar = explode('.', $namaFile);
        $ekstensiGambar = strtolower(end($ekstensiGambar));
        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
            echo "<script>
        alert('yang diupload bukan file gambar!')
        document.location='?'
        </script>";
            return false;
        }

        // cek jika ukuran terlalu besar
        if ($ukuranFile > 1000000) {
            echo "<script>
        alert('ukuran gambar terlalu besar!')
        document.location='?'
        </script>";
            return false;
        }

        // lolos pengecekan, gambar siap diupload
        // generate nama file baru
        $namaFileBaru = uniqid();
        $namaFileBaru .= '.';
        $namaFileBaru .= $ekstensiGambar;

        move_uploaded_file($tmpName, __DIR__ . '/img/' . $namaFileBaru);

        return $namaFileBaru;
    }


    ?>

   <!-- custom animated -->
   <link href="assets/css/animated.css" rel="stylesheet" type="text/css">

   <!-- Head -->
   <div class="head text-center">
       <img src="assets/img/airmu4.png" width="200">
       <h2 class="text-white">Sistem Inventaris Barang <br>
           <b>AIR MU</b>
       </h2>
   </div>
   <!-- end Head -->

   <!-- Awal Row -->
   <div class="row mt-2">
       <!-- col-lg-7 -->
       <div class="col-lg-7 mb-3">
           <div class="card shadow bg-gradient-light">
               <!-- card body -->
               <div class="card-body">
                   <div class="text-center">
                       <h1 class="h4 text-gray-900 mb-4"><b>INFORMASI BARANG</b></h1>
                   </div>
                   <form class="user" method="POST" action="" enctype="multipart/form-data">
                       <div class="form-group">
                           <input type="text" class="form-control 
                                    form- control-user" name="nama" placeholder="Nama Barang" required>
                       </div>
                       <div class="form-group">
                           <input type="text" class="form-control 
                                    form- control-user" name="alamat" placeholder=" Deskripsi Barang" minlength="3" required>
                       </div>
                       <div class="form-group">
                           <select name="tujuan" class="form-control form- control-user" required>
                               <option value="">Satuan Barang</option>
                               <option value="pcs">pcs</option>
                               <option value="pack">pack</option>
                       </div>
                       <div class="form-group">
                           <input type="text" class="form-control 
                                    form- control-user" name="nope" placeholder="Jumlah Barang" required pattern="\d+" title="Input hanya boleh mengandung angka">
                       </div>
                       <div class="form-group">
                           <input type="file" name="gambar" placeholder="">
                       </div>

                       <button type="submit" name="bsimpan" class="btn btn-primary btn-user btn-block">Simpan Data</button>

                   </form>
                   <hr>
                   <div class="text-center">
                       <a class="small" href="#">Inspiration on You tube <?= date('Y')
                                                                            ?></a>
                   </div>
               </div>
               <!-- end card-body -->
           </div>
       </div>
       <!-- end col-lg-7 -->

       <!-- col-lg-5 -->
       <div class="col-lg-5 mb-3">
           <!-- Collapsable Card Example -->
           <div class="card shadow mb-4">
               <!-- Card Header - Accordion -->
               <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                   <h6 class="m-0 font-weight-bold text-center">STATISTIK BARANG</h6>
               </a>
               <!-- Card Content - Collapse -->
               <div class="collapse show" id="collapseCardExample">
                   <div class="card-body">
                       <?php
                        // deklarasi tanggal

                        // menampilkan tanggal sekarang
                        $tgl_sekarang = date('Y-m-d');

                        // menampilkan tgl kemarin
                        $kemarin = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));

                        //mendapatkan 6 hari sebelum skrg
                        $seminggu = date('Y-m-d h:i:s', strtotime('-1 week +1 day', strtotime($tgl_sekarang)));

                        $sekarang = date('Y-m-d h:i:s');

                        // persiapan query tampilkan jumlah data pengunjung

                        $tgl_sekarang = mysqli_fetch_array(
                            mysqli_query(
                                $koneksi,
                                "SELECT count(*) FROM tdata where tanggal like'%$tgl_sekarang%'"
                            )
                        );

                        $kemarin = mysqli_fetch_array(
                            mysqli_query(
                                $koneksi,
                                "SELECT count(*) FROM tdata where tanggal like'%$kemarin%'"
                            )
                        );

                        $seminggu = mysqli_fetch_array(
                            mysqli_query(
                                $koneksi,
                                "SELECT count(*) FROM tdata where tanggal BETWEEN '$seminggu' and
                                    '$sekarang'"
                            )
                        );

                        $bukan_ini = date('m');

                        $sebulan = mysqli_fetch_array(
                            mysqli_query(
                                $koneksi,
                                "SELECT count(*) FROM tdata where month(tanggal) = '$bukan_ini'"
                            )
                        );

                        $keseluruhan = mysqli_fetch_array(
                            mysqli_query(
                                $koneksi,
                                "SELECT count(*) FROM tdata"
                            )
                        );



                        ?>
                       <table class="table table-bordered">
                           <tr>
                               <td><i class="fas fa-user text-primary"></i> Hari ini</td>
                               <td>:
                                   <?= $tgl_sekarang[0] ?>
                               </td>
                           </tr>
                           <tr>
                               <td><i class="fas fa-user-friends text-success"></i> Kemarin</td>
                               <td>:
                                   <?= $kemarin[0] ?>
                               </td>
                           </tr>
                           <tr>
                               <td><i class="fas fa-users text-info"></i> Minggu ini</td>
                               <td>:
                                   <?= $seminggu[0] ?>
                               </td>
                           </tr>
                           <tr>
                               <td><i class="fas fa-chart-pie text-warning"></i> Bulan ini</td>
                               <td>:
                                   <?= $sebulan[0] ?>
                               </td>
                           </tr>
                           <tr>
                               <td><i class="fas fa-chart-line text-danger"></i> Keseluruhan</td>
                               <td>:
                                   <?= $keseluruhan[0] ?>
                               </td>
                           </tr>
                       </table>
                   </div>
               </div>
           </div>

       </div>
       <!-- end col-lg-5 -->


   </div>
   <!-- end row -->

   <!-- DataTales Example -->
   <div class="card shadow mb-4">
       <div class="card-header py-3">
           <h6 class="m-0 font-weight-bold text-primary">Data Barang Hari ini [<?=
                                                                                date('d-m-Y') ?>]</h6>
       </div>
       <div class="card-body">
           <a href="rekapitulasi.php" class="btn btn-success mb-3"><i class="fa 
                          fa-table"></i>Rekapitulasi Pengunjung</a>
           <a href="logout.php" class="btn btn-danger mb-3" onclick="return confirm('Apakah Anda yakin ingin keluar?')"><i class="fa 
                          fa-sign-out-alt"></i> Logout</a>


           <div class="table-responsive">
               <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                       <tr>
                           <th>No.</th>
                           <th>Tanggal</th>
                           <th>Nama Barang</th>
                           <th>Deskripsi</th>
                           <th>Satuan</th>
                           <th>Jumlah</th>
                           <th>Gambar</th>
                       </tr>
                   </thead>
                   <tfoot>
                       <tr>
                           <th>No.</th>
                           <th>Tanggal</th>
                           <th>Nama Barang</th>
                           <th>Deskripsi</th>
                           <th>Satuan</th>
                           <th>Jumlah</th>
                           <th>Gambar</th>
                       </tr>
                   </tfoot>
                   <tbody>
                       <?php
                        $tgl = date('Y-m-d'); //2023-05-19
                        $tampil = mysqli_query($koneksi, "SELECT * FROM tdata where
                                            tanggal like '%$tgl%' order by id desc");
                        $no = 1;

                        while ($data = mysqli_fetch_array($tampil)) {
                        ?>
                           <tr>
                               <td><?= $no++ ?></td>
                               <td><?= $data['tanggal'] ?></td>
                               <td><?= $data['nama'] ?></td>
                               <td><?= $data['alamat'] ?></td>
                               <td><?= $data['tujuan'] ?></td>
                               <td><?= $data['nope'] ?></td>
                               <td><img src="img/<?php echo $data['gambar'] ?>" alt="<?= $data['nama'] ?>" style="width: 100px; height: auto;"></td>
                           </tr>
                       <?php } ?>
                   </tbody>
               </table>
           </div>
       </div>
   </div>

   <!-- panggil file footer -->
   <?php include "footer.php"; ?>