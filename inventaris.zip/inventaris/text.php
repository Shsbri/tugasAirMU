
  <style>
    h2 {
      font-size: 37px;
      color: white;
      font-family: Arial, sans-serif;
      font-weight: bold;
      transition: 0.3s;
      transform: scale(1);
    }
    h2:hover {
      color: white;
      font-weight: bold;
      transform: scale(1.2);
    }
  </style>

  <h2 id="teks" onmouseover="ubahTeks()" onmouseout="kembalikanTeks()"> AIR MU</h2>
  
  <script>
    function ubahTeks() {
      var teks = document.getElementById('teks');
      teks.textContent = 'MUHAMMADIYAH';
    }
    
    function kembalikanTeks() {
      var teks = document.getElementById('teks');
      teks.textContent = 'AIR MU';
    }
  </script>