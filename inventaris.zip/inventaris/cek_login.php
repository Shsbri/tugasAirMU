<?php

// Aktifkan session
session_start();

// Panggil koneksi database
include "koneksi.php";

@$username = mysqli_escape_string($koneksi, $_POST['username']);
@$userpass = mysqli_escape_string($koneksi, $_POST['password']);

$login = mysqli_query($koneksi, "SELECT * FROM tuser WHERE username = '$username'");

if ($login && mysqli_num_rows($login) > 0) {
    $data = mysqli_fetch_array($login);
    
    // Verifikasi password
    if (password_verify($userpass, $data['password'])) {
        // Set session
        $_SESSION['id_user'] = $data['id_user'];
        $_SESSION['nama_pengguna'] = $data['nama_pengguna'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['password'] = $data['password'];

        // Tampilkan pesan berhasil login dan arahkan ke halaman admin
        echo "<script>
        alert('Selamat Anda Berhasil Login!');
        window.location.href = 'admin.php';
        </script>";
        exit();
    } else {
        echo "<script>
        alert('Maaf, Login Gagal, Pastikan Username dan Password anda Benar..!'); 
        window.location.href = 'index.php';
        </script>";
    }
} else {
    echo "<script>
    alert('Maaf, Login Gagal, Pastikan Username dan Password anda Benar..!'); 
    window.location.href = 'index.php';
    </script>";
}
?>
